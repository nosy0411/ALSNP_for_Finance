# Pandas-Groupby

Supporting CSV files for the article [All You Need to Know About Pandas' GroupBy](https://realpython.com/pandas-groupby/).
