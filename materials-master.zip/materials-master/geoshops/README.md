# Create a Location-Based Web App with Django and GeoDjango

Sample app for Real Python's *Make a Location-Based Web App With Django and GeoDjango* [Python course](https://realpython.com/courses/).
