from django.apps import AppConfig


class NearbyshopsConfig(AppConfig):
    name = "nearbyshops"
