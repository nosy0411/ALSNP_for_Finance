# Example 4

This example uses the raw author_book_publisher.csv file to
get data into the program and run various python functions
on it. 

The csv file uses redundant data to hold relationship data
in the file. The main.py program examines this file to use
those reletionships to get different kinds of information
from the file.