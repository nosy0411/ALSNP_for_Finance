# Example 6

This example uses SqlAlcheym to access the author_book_publisher.db
sqlite file to get data into the program and run various python functions
on it. 

The main.py program file shows how to use the objects returned
by SqlAlchemy, and the relationships coded into them, to retreive
the same information the previous example programs did.