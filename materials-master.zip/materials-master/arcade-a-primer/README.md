Source files supporting the **Arcade - A Modern Python Game Framework** article
