# Speed Up Your Python Program With Concurrency: Code Examples

Corresponding code to the Real Python tutorial, "[Speed up your Python Program with Concurrency](https://realpython.com/python-concurrency/)."

To run the code here, use:

    pip install -r requirements.txt

This will ensure you have the required packages.
