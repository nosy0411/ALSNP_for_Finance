# Explore Your Dataset With Python and Pandas

Code snippets supplementing the [Using Pandas and Python to Explore Your Dataset](https://realpython.com/pandas-python-explore-dataset/) article on [Real Python](https://realpython.com/).
