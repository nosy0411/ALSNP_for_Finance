from django.apps import AppConfig


class HistoricalDataConfig(AppConfig):
    name = "historical_data"
