float cmult(int int_param, float float_param);
