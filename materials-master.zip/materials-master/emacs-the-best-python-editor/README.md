Support file for the Emacs: The Best Python Editor article.
