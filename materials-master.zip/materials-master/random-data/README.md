# Generating Random Data in Python

Corresponding scripts for ["Generating Random Data in Python."](https://realpython.com/python-random/)
