# Make a Location-Based Web App With Django and GeoDjango

This folder contains the bonus material & example projects for our [Make a Location-Based Web App With Django and GeoDjango](https://realpython.com/location-based-app-with-geodjango-tutorial) tutorial on Real Python.

Check out [Make a Location-Based Web App With Django and GeoDjango](https://realpython.com/location-based-app-with-geodjango-tutorial/) for more information. 

